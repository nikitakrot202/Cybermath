<?php
function getRandomEmoji() {
    $emojis = ['📚', '🧮', '🔢', '➕', '➖', '✖️', '➗', '💡', '🎯', '🧠', '📝', '📊', '🔍', '✅', '📖', '📘'];
    return $emojis[array_rand($emojis)];
}

function generateTheoryTemplate($title, $content, $imageHtml, $topicNumber, $language) {
    $emoji = getRandomEmoji();
    
    $styles = <<<CSS
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            position: relative;
            overflow-x: hidden;
        }
        h1 {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
        }

        .task-navigation {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
        }
        .task-navigation .btn {
            min-width: 120px;
        }
        .task-counter {
            font-size: 1.2rem;
            margin-bottom: 15px;
            font-weight: bold;
            text-align: center;
        }

        .card {
            background: #ffffffcc;
            border: none;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .emoji {
            position: absolute;
            font-size: 2rem;
            animation: float 10s infinite linear;
            opacity: 0.8;
        }
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 0.8; }
            100% { transform: translateY(-200px) rotate(360deg); opacity: 0; }
        }
        .btn-primary {
            background-color: #6c5ce7;
            border: none;
        }
        .btn-primary:hover {
            background-color: #5a4bd1;
        }
        .img-fluid {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin: 15px 0;
        }
    </style>
CSS;

    if ($language === 'et') {
        return <<<HTML
<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <title>{$title} - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    {$styles}
</head>
<body class="container py-5 position-relative">
    <?php for (\$i = 0; \$i < 15; \$i++): ?>
        <div class="emoji" style="left: <?= rand(0, 100) ?>%; top: <?= rand(10, 100) ?>px; animation-delay: <?= rand(0, 10) ?>s;">
            <?= ['🔢','✨','🧠','➕','➖','📘','🚀','🧮'][rand(0, 7)] ?>
        </div>
    <?php endfor; ?>

    <div class="card mx-auto" style="max-width: 900px;">
        <h1 class="mb-4 text-center">{$emoji} {$title}</h1>
        {$imageHtml}
        <div class="theory-content">{$content}</div>
        <p class="text-center mt-4">
            <a href="../tasks/topic{$topicNumber}.php" class="btn btn-primary btn-lg fw-bold">Mine näidete juurde 🚀</a>
        </p>
    </div>
</body>
</html>
HTML;
    } else {
        return <<<HTML
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>{$title} - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    {$styles}
</head>
<body class="container py-5 position-relative">
    <?php for (\$i = 0; \$i < 15; \$i++): ?>
        <div class="emoji" style="left: <?= rand(0, 100) ?>%; top: <?= rand(10, 100) ?>px; animation-delay: <?= rand(0, 10) ?>s;">
            <?= ['🔢','✨','🧠','➕','➖','📘','🚀','🧮'][rand(0, 7)] ?>
        </div>
    <?php endfor; ?>

    <div class="card mx-auto" style="max-width: 900px;">
        <h1 class="mb-4 text-center">{$emoji} {$title}</h1>
        {$imageHtml}
        <div class="theory-content">{$content}</div>
        <p class="text-center mt-4">
            <a href="../tasks/topic{$topicNumber}.php" class="btn btn-primary btn-lg fw-bold">Перейти к примерам 🚀</a>
        </p>
    </div>
</body>
</html>
HTML;
    }
}

function generateTasksTemplate($title, $tasksArrayContent, $topicNumber, $language) {
    $taskStyles = <<<CSS
    <style>
        body {
            background: linear-gradient(to right, #f9f9f9, #eef3f7);
            font-family: 'Segoe UI', sans-serif;
        }
        .task-card {
            animation: fadeInUp 0.5s ease;
            transition: transform 0.3s;
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .task-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        }

        .task-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        .task-number {
            font-weight: bold;
            font-size: 1.1rem;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animated-alert {
            animation: fadeIn 0.8s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .btn-success {
            transition: background-color 0.3s;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .img-fluid {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin: 15px 0;
        }
        .task-navigation {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
        }
        .task-counter {
            font-size: 1.2rem;
            margin-bottom: 15px;
            font-weight: bold;
            text-align: center;
        }
    </style>
CSS;

    if ($language === 'et') {
        return <<<PHP
<?php
session_start();
require_once '../../../db.php';

\$currentTask = isset(\$_GET['task']) ? (int)\$_GET['task'] : 1;
if (\$currentTask < 1 || \$currentTask > count(\$tasks)) {
    \$currentTask = 1;
}

if (!isset(\$_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

\$user_id = \$_SESSION['user_id'];
\$topic_id = {$topicNumber};

\$tasks = {$tasksArrayContent}

\$show_result = false;
\$score = 0;
\$user_answers = [];
\$earned_bonus = false;

if (\$_SERVER['REQUEST_METHOD'] === 'POST') {
    \$show_result = true;

    foreach (\$tasks as \$i => \$task) {
        \$user_answer = \$_POST['q' . \$i] ?? null;
        \$user_answers[\$i] = \$user_answer;

        if (\$user_answer == \$task['answer']) {
            \$score++;
        }
    }

    if (\$score === count(\$tasks)) {
        \$stmt = \$pdo->prepare("SELECT COUNT(*) FROM user_topics WHERE user_id = ? AND topic_id = ?");
        \$stmt->execute([\$user_id, \$topic_id]);
        \$already_completed = \$stmt->fetchColumn();

        if (\$already_completed == 0) {
            \$insert = \$pdo->prepare("INSERT INTO user_topics (user_id, topic_id) VALUES (?, ?)");
            \$insert->execute([\$user_id, \$topic_id]);
            \$earned_bonus = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <title>Ülesanded: {$title}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    {$taskStyles}
</head>
<body class="container py-5">
    <h1 class="mb-4 text-center">🧠 {$title}</h1>

    <div class="task-counter">
        Ülesanne <?= \$currentTask ?> / <?= count(\$tasks) ?>
    </div>

    <?php if (\$show_result): ?>
        <div class="alert alert-info animated-alert text-center fs-5">
            Sa lahendasid õigesti <?= \$score ?> / <?= count(\$tasks) ?> ülesannet!
            <?php if (\$score === count(\$tasks) && \$earned_bonus): ?>
                <br><strong class="text-success">+50 münti 💰</strong>
            <?php elseif (\$score === count(\$tasks)): ?>
                <br><em class="text-muted">(juba varem läbitud)</em>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-4 p-4 task-card">
            <h5><?= \$tasks[\$currentTask-1]['question'] ?></h5>
            <?php foreach (\$tasks[\$currentTask-1]['options'] as \$opt): ?>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q<?= \$currentTask-1 ?>" value="<?= \$opt ?>"
                        <?= isset(\$user_answers[\$currentTask-1]) && \$user_answers[\$currentTask-1] == \$opt ? 'checked' : '' ?> 
                        <?= \$show_result ? 'disabled' : '' ?>>
                    <label class="form-check-label"><?= \$opt ?></label>
                </div>
            <?php endforeach; ?>

            <?php if (\$show_result): ?>
                <?php if (!isset(\$user_answers[\$currentTask-1])): ?>
                    <div class="mt-2 text-warning">❌ Vastus puudub</div>
                <?php elseif (\$user_answers[\$currentTask-1] == \$tasks[\$currentTask-1]['answer']): ?>
                    <div class="mt-2 text-success">✅ Õige!</div>
                <?php else: ?>
                    <div class="mt-2 text-danger">❌ Vale. Õige vastus: <?= \$tasks[\$currentTask-1]['answer'] ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="task-navigation">
            <?php if (\$currentTask > 1): ?>
                <a href="?task=<?= \$currentTask - 1 ?>" class="btn btn-primary">Eelmine</a>
            <?php else: ?>
                <span class="btn btn-secondary disabled">Eelmine</span>
            <?php endif; ?>
            
            <?php if (\$currentTask < count(\$tasks)): ?>
                <a href="?task=<?= \$currentTask + 1 ?>" class="btn btn-primary">Järgmine</a>
            <?php else: ?>
                <span class="btn btn-secondary disabled">Järgmine</span>
            <?php endif; ?>
        </div>

        <div class="text-center mt-4">
            <?php if (!\$show_result): ?>
                <button type="submit" class="btn btn-success btn-lg px-5">Näita tulemust</button>
            <?php elseif (\$score < count(\$tasks)): ?>
                <a href="" class="btn btn-warning btn-lg px-5">Proovi uuesti</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="text-center mt-4">
        <a href="../theory/index.php" class="btn btn-outline-secondary">← Tagasi teemade juurde</a>
    </div>
</body>
</html>
PHP;
    } else {
        return <<<PHP
<?php
session_start();
require_once '../../../db.php';

\$currentTask = isset(\$_GET['task']) ? (int)\$_GET['task'] : 1;
if (\$currentTask < 1 || \$currentTask > count(\$tasks)) {
    \$currentTask = 1;
}

if (!isset(\$_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

\$user_id = \$_SESSION['user_id'];
\$topic_id = {$topicNumber};

\$tasks = {$tasksArrayContent}

\$show_result = false;
\$score = 0;
\$user_answers = [];
\$earned_bonus = false;

if (\$_SERVER['REQUEST_METHOD'] === 'POST') {
    \$show_result = true;

    foreach (\$tasks as \$i => \$task) {
        \$user_answer = \$_POST['q' . \$i] ?? null;
        \$user_answers[\$i] = \$user_answer;

        if (\$user_answer == \$task['answer']) {
            \$score++;
        }
    }

    if (\$score === count(\$tasks)) {
        \$stmt = \$pdo->prepare("SELECT COUNT(*) FROM user_topics WHERE user_id = ? AND topic_id = ?");
        \$stmt->execute([\$user_id, \$topic_id]);
        \$already_completed = \$stmt->fetchColumn();

        if (\$already_completed == 0) {
            \$insert = \$pdo->prepare("INSERT INTO user_topics (user_id, topic_id) VALUES (?, ?)");
            \$insert->execute([\$user_id, \$topic_id]);
            \$earned_bonus = true;
        }
    }
}
?>
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задачи: {$title}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    {$taskStyles}
</head>
<body class="container py-5">
    <h1 class="mb-4 text-center">🧠 {$title}</h1>

    <div class="task-counter">
        Задача <?= \$currentTask ?> из <?= count(\$tasks) ?>
    </div>

    <?php if (\$show_result): ?>
        <div class="alert alert-info animated-alert text-center fs-5">
            Вы правильно решили <?= \$score ?> из <?= count(\$tasks) ?> задач!
            <?php if (\$score === count(\$tasks) && \$earned_bonus): ?>
                <br><strong class="text-success">+50 монет 💰</strong>
            <?php elseif (\$score === count(\$tasks)): ?>
                <br><em class="text-muted">(уже пройдено ранее)</em>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-4 p-4 task-card">
            <h5><?= \$tasks[\$currentTask-1]['question'] ?></h5>
            <?php foreach (\$tasks[\$currentTask-1]['options'] as \$opt): ?>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q<?= \$currentTask-1 ?>" value="<?= \$opt ?>"
                        <?= isset(\$user_answers[\$currentTask-1]) && \$user_answers[\$currentTask-1] == \$opt ? 'checked' : '' ?> 
                        <?= \$show_result ? 'disabled' : '' ?>>
                    <label class="form-check-label"><?= \$opt ?></label>
                </div>
            <?php endforeach; ?>

            <?php if (\$show_result): ?>
                <?php if (!isset(\$user_answers[\$currentTask-1])): ?>
                    <div class="mt-2 text-warning">❌ Нет ответа</div>
                <?php elseif (\$user_answers[\$currentTask-1] == \$tasks[\$currentTask-1]['answer']): ?>
                    <div class="mt-2 text-success">✅ Правильно!</div>
                <?php else: ?>
                    <div class="mt-2 text-danger">❌ Неправильно. Правильный ответ: <?= \$tasks[\$currentTask-1]['answer'] ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="task-nav mb-4">
            <div><span class="task-number">Задача <?= \$currentTask ?> / <?= count(\$tasks) ?></span></div>
            <div>
                <?php if (\$currentTask > 1): ?>
                    <a href="?task=<?= \$currentTask - 1 ?>" class="btn btn-outline-primary btn-sm me-2">← Предыдущая</a>
                <?php endif; ?>
                <?php if (\$currentTask < count(\$tasks)): ?>
                    <a href="?task=<?= \$currentTask + 1 ?>" class="btn btn-outline-primary btn-sm">Следующая →</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="text-center mt-4">
            <?php if (!\$show_result): ?>
                <button type="submit" class="btn btn-success btn-lg px-5">Показать результат</button>
            <?php elseif (\$score < count(\$tasks)): ?>
                <a href="" class="btn btn-warning btn-lg px-5">Попробовать снова</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="text-center mt-4">
        <a href="../theory/index.php" class="btn btn-outline-secondary">← Назад к темам</a>
    </div>
</body>
</html>
PHP;
    }
}

function getAdminLangStrings($language) {
    $strings = [
        'ru' => [
            'create_new' => 'Создать новую тему',
            'back_to_admin' => 'Вернуться в админку',
            'view_theory' => 'Открыть теорию',
            'view_tasks' => 'Открыть задачи',
            'create_topic_title' => 'Создание новой темы',
            'create_new_topic' => 'Создать новую тему',
            'topic_deleted' => 'Тема №%s успешно удалена!',
            'back_to_admin' => 'Вернуться в админку',
            'view_topics_list' => 'Просмотр списка тем',
            'view_tasks_list' => 'Просмотр списка задач',
            'theory_and_examples' => 'Теория и примеры',
            'math_tasks' => 'Математические задачи',
            'topic_name' => 'Название темы',
            'theory_content' => 'Подробная теория',
            'theory_image' => 'Изображение для теории',
            'image_requirements' => 'Максимальный размер: 2MB. Допустимые форматы: JPG, PNG, GIF',
            'tasks' => 'Задания',
            'add_task' => 'Добавить задание',
            'generate_topic' => 'Сгенерировать тему',
            'cancel' => 'Отмена',
            'tasks_topic_name' => 'Название темы задач',
            'task_count' => 'Количество задач',
            'generate_tasks' => 'Сгенерировать задачи',
            'existing_topics' => 'Список существующих тем',
            'topic' => 'Тема',
            'no_topics' => 'Нет созданных тем',
            'delete' => 'Удалить',
            'confirm_delete_topic' => 'Вы уверены, что хотите удалить тему',
            'existing_tasks' => 'Список существующих задач',
            'no_tasks' => 'Нет созданных задач',
            'confirm_delete_tasks' => 'Вы уверены, что хотите удалить задачи темы',
            'task' => 'Задание',
            'question' => 'Вопрос',
            'task_image' => 'Изображение для задания',
            'options' => 'Варианты ответов',
            'options_hint' => 'Через запятую',
            'correct_answer' => 'Правильный ответ',
            'delete_task' => 'Удалить задание',
            'question_template' => 'Шаблон вопроса',
            'variables_hint' => 'Используйте {x}, {y}, {z} для переменных',
            'answer_formula' => 'Формула для ответа',
            'formula_hint' => 'Например: x + y - z',
            'min_value' => 'Минимальное значение',
            'max_value' => 'Максимальное значение',
            'tasks_for' => 'Задачи',
            'page_title' => 'Генерация темы',
            'error' => 'Ошибка',
            'success_title' => 'Тема успешно создана!',
            'success_message' => 'Тема "%s" была сохранена как тема №%d.',
            'view_theory' => 'Открыть теорию',
            'view_tasks' => 'Открыть задачи',
            'fail_title' => 'Ошибка при создании темы',
            'fail_message' => 'Пожалуйста, попробуйте снова.',
            'fail_message_with_reason' => 'Причина: %s'
        ],
        'et' => [
            'create_new' => 'Loo uus teema',
            'back_to_admin' => 'Tagasi administraatorilehele',
            'view_theory' => 'Vaata teooriat',
            'view_tasks' => 'Vaata ülesandeid',
            'create_topic_title' => 'Uue teema loomine',
            'create_new_topic' => 'Loo uus teema',
            'topic_deleted' => 'Teema nr %s kustutati edukalt!',
            'back_to_admin' => 'Tagasi administraatorilehele',
            'view_topics_list' => 'Vaata teemade nimekirja',
            'view_tasks_list' => 'Vaata ülesannete nimekirja',
            'theory_and_examples' => 'Teooria ja näited',
            'math_tasks' => 'Matemaatilised ülesanded',
            'topic_name' => 'Teema pealkiri',
            'theory_content' => 'Üksikasjalik teooria',
            'theory_image' => 'Teooria pilt',
            'image_requirements' => 'Maksimaalne suurus: 2MB. Lubatud formaadid: JPG, PNG, GIF',
            'tasks' => 'Ülesanded',
            'add_task' => 'Lisa ülesanne',
            'generate_topic' => 'Loo teema',
            'cancel' => 'Tühista',
            'tasks_topic_name' => 'Ülesannete teema pealkiri',
            'task_count' => 'Ülesannete arv',
            'generate_tasks' => 'Loo ülesanded',
            'existing_topics' => 'Olemasolevad teemad',
            'topic' => 'Teema',
            'no_topics' => 'Ühtegi teemat pole loodud',
            'delete' => 'Kustuta',
            'confirm_delete_topic' => 'Kas olete kindel, et soovite kustutada teema',
            'existing_tasks' => 'Olemasolevad ülesanded',
            'no_tasks' => 'Ühtegi ülesannet pole loodud',
            'confirm_delete_tasks' => 'Kas olete kindel, et soovite kustutada teema ülesanded',
            'task' => 'Ülesanne',
            'question' => 'Küsimus',
            'task_image' => 'Ülesande pilt',
            'options' => 'Vastusevariandid',
            'options_hint' => 'Komadega eraldatud',
            'correct_answer' => 'Õige vastus',
            'delete_task' => 'Kustuta ülesanne',
            'question_template' => 'Küsimuse mall',
            'variables_hint' => 'Kasutage muutujate jaoks {x}, {y}, {z}',
            'answer_formula' => 'Vastuse valem',
            'formula_hint' => 'Näiteks: x + y - z',
            'min_value' => 'Minimaalne väärtus',
            'max_value' => 'Maksimaalne väärtus',
            'tasks_for' => 'Ülesanded',
            'page_title' => 'Teema loomine',
            'error' => 'Viga',
            'success_title' => 'Teema loodud edukalt!',
            'success_message' => 'Teema "%s" salvestati teemana nr %d.',
            'view_theory' => 'Vaata teooriat',
            'view_tasks' => 'Vaata ülesandeid',
            'fail_title' => 'Viga teema loomisel',
            'fail_message' => 'Palun proovi uuesti.',
            'fail_message_with_reason' => 'Põhjus: %s'
        ]
    ];
    
    return $strings[$language] ?? $strings['ru'];
}