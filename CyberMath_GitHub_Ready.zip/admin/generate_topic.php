<?php
session_start();
require_once '../db.php';
require_once 'language_functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/admin_login.php');
    exit;
}

$language = $_POST['language'] ?? 'ru';

// Константы для загрузки изображений
define('MAX_IMAGE_SIZE', 2 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('THEORY_IMAGES_DIR', "../language/$language/theory/images");
define('TASK_IMAGES_DIR', "../language/$language/tasks/images");

function createPHPFile($path, $content) {
    $file = fopen($path, 'w');
    if ($file === false) {
        throw new Exception("Не удалось создать файл: $path");
    }
    fwrite($file, $content);
    fclose($file);
}

function escapeForArray($value) {
    $value = trim($value);
    if (is_numeric($value)) {
        return $value;
    }
    return '"' . addslashes($value) . '"';
}

function validateAndSaveImage($file, $targetDir, $baseName) {
    if (!is_array($file) || !isset($file['error'])) {
        throw new Exception("Некорректные данные файла");
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Ошибка загрузки файла: " . $file['error']);
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, ALLOWED_IMAGE_TYPES)) {
        throw new Exception("Недопустимый тип файла");
    }

    if ($file['size'] > MAX_IMAGE_SIZE) {
        throw new Exception("Файл слишком большой");
    }

    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $imageName = $baseName . '.' . $extension;
    $imagePath = "$targetDir/$imageName";

    if (!move_uploaded_file($file['tmp_name'], $imagePath)) {
        throw new Exception("Не удалось сохранить файл");
    }

    return $imageName;
}

$success = false;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $topicName = trim($_POST['topic_name']);
        $theoryText = trim($_POST['theory_text']);
        $tasks = $_POST['tasks'] ?? [];
        
        if (empty($tasks)) {
            throw new Exception("Не были предоставлены задачи");
        }
        
        $existing = glob("../language/$language/theory/topic*.php");
        $nextNumber = count($existing) + 1;
        
        // Обработка изображения для теории
        $theoryImageName = null;
        if (!empty($_FILES['theory_image']['name'])) {
            $theoryImageName = validateAndSaveImage($_FILES['theory_image'], THEORY_IMAGES_DIR, "topic{$nextNumber}_theory");
        }

        // Генерация теории
        $theoryImageHtml = $theoryImageName 
            ? "<div class='text-center my-4'><img src='images/$theoryImageName' class='img-fluid rounded' alt='Illustration'></div>" 
            : "";
        $theoryContent = generateTheoryTemplate($topicName, $theoryText, $theoryImageHtml, $nextNumber, $language);

        // Генерация задач
        $tasksArrayContent = "[\n";
        foreach ($tasks as $i => $task) {
            $question = str_replace(['"', "\n", "\r", '<?php', '?>'], ['\"', '', '', '&lt;?php', '?&gt;'], $task['question']);
            $options = array_map('trim', explode(',', $task['options']));
            
            // Обработка изображения для задачи
            $taskImageName = null;
            if (!empty($_FILES['tasks']['tmp_name'][$i]['image'])) {
                $taskImageName = validateAndSaveImage(
                    [
                        'name' => $_FILES['tasks']['name'][$i]['image'],
                        'type' => $_FILES['tasks']['type'][$i]['image'],
                        'tmp_name' => $_FILES['tasks']['tmp_name'][$i]['image'],
                        'error' => $_FILES['tasks']['error'][$i]['image'],
                        'size' => $_FILES['tasks']['size'][$i]['image']
                    ], 
                    TASK_IMAGES_DIR, 
                    "topic{$nextNumber}_task{$i}"
                );
                
                // Добавляем изображение к вопросу
                $question = "<div class='mb-3 text-center'><img src='images/$taskImageName' class='img-fluid rounded' style='max-height: 200px;'></div>" . $question;
            }
            
            $optionsArray = "[" . implode(", ", array_map('escapeForArray', $options)) . "]";
            $answer = escapeForArray($task['answer']);
            
            $tasksArrayContent .= "    [\n";
            $tasksArrayContent .= "        'question' => \"{$question}\",\n";
            $tasksArrayContent .= "        'options' => {$optionsArray},\n";
            $tasksArrayContent .= "        'answer' => {$answer}\n";
            $tasksArrayContent .= "    ],\n";
        }
        $tasksArrayContent .= "];";

        // Полный шаблон файла примера
        $tasksContent = <<<PHP
<?php
session_start();
require_once '../../../db.php';

if (!isset(\$_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

\$user_id = \$_SESSION['user_id'];
\$topic_id = $nextNumber;

\$tasks = $tasksArrayContent

\$show_result = false;
\$score = 0;
\$user_answers = [];
\$earned_bonus = false;

if (\$_SERVER['REQUEST_METHOD'] === 'POST') {
    \$show_result = true;

    foreach (\$tasks as \$i => \$task) {
        \$user_answer = \$_POST['q' . \$i] ?? null;
        \$user_answers[\$i] = \$user_answer;

        if (\$user_answer == \$task['answer']) {
            \$score++;
        }
    }

    if (\$score === count(\$tasks)) {
        \$stmt = \$pdo->prepare("SELECT COUNT(*) FROM user_topics WHERE user_id = ? AND topic_id = ?");
        \$stmt->execute([\$user_id, \$topic_id]);
        \$already_completed = \$stmt->fetchColumn();

        if (\$already_completed == 0) {
            \$insert = \$pdo->prepare("INSERT INTO user_topics (user_id, topic_id) VALUES (?, ?)");
            \$insert->execute([\$user_id, \$topic_id]);
            \$earned_bonus = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задачи: $topicName</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f9f9f9, #eef3f7);
            font-family: 'Segoe UI', sans-serif;
        }
        .task-card {
            animation: fadeInUp 0.5s ease;
            transition: transform 0.3s;
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .task-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animated-alert {
            animation: fadeIn 0.8s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .btn-success {
            transition: background-color 0.3s;
        }
        .btn-success:hover {
            background-color: #218838;
        }
    </style>
</head>
<body class="container py-5">
    <h1 class="mb-4 text-center">🧠 $topicName</h1>

    <?php if (\$show_result): ?>
        <div class="alert alert-info animated-alert text-center fs-5">
            Вы правильно решили <?= \$score ?> из <?= count(\$tasks) ?> задач!
            <?php if (\$score === count(\$tasks) && \$earned_bonus): ?>
                <br><strong class="text-success">+50 монет 💰</strong>
            <?php elseif (\$score === count(\$tasks)): ?>
                <br><em class="text-muted">(уже пройдено ранее)</em>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <?php foreach (\$tasks as \$index => \$task): ?>
            <div class="mb-4 p-4 task-card">
                <h5><?= (\$index + 1) . ') ' . \$task['question'] ?></h5>
                <?php foreach (\$task['options'] as \$opt): ?>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="q<?= \$index ?>" value="<?= \$opt ?>"
                            <?= isset(\$user_answers[\$index]) && \$user_answers[\$index] == \$opt ? 'checked' : '' ?> 
                            <?= \$show_result ? 'disabled' : '' ?>>
                        <label class="form-check-label"><?= \$opt ?></label>
                    </div>
                <?php endforeach; ?>

                <?php if (\$show_result): ?>
                    <?php if (!isset(\$user_answers[\$index])): ?>
                        <div class="mt-2 text-warning">❌ Нет ответа</div>
                    <?php elseif (\$user_answers[\$index] == \$task['answer']): ?>
                        <div class="mt-2 text-success">✅ Правильно!</div>
                    <?php else: ?>
                        <div class="mt-2 text-danger">❌ Неправильно. Правильный ответ: <?= \$task['answer'] ?></div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <div class="text-center mt-4">
            <?php if (!\$show_result): ?>
                <button type="submit" class="btn btn-success btn-lg px-5">Показать результат</button>
            <?php elseif (\$score < count(\$tasks)): ?>
                <a href="" class="btn btn-warning btn-lg px-5">Попробовать снова</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="text-center mt-4">
        <a href="../theory/index.php" class="btn btn-outline-secondary">← Назад к темам</a>
    </div>
</body>
</html>
PHP;

        // Создаем файлы
        createPHPFile("../language/$language/theory/topic{$nextNumber}.php", $theoryContent);
        createPHPFile("../language/$language/tasks/topic{$nextNumber}.php", $tasksContent);
        
        // Обновляем список тем
        $topicsFile = "../language/$language/theory/index.php";
        $topicsContent = file_get_contents($topicsFile);
        if (preg_match('/\$topics\s*=\s*\[([^\]]+)\]/', $topicsContent, $matches)) {
            $currentTopics = $matches[1];
            $newTopics = rtrim($currentTopics) . "\n    \"" . addslashes($topicName) . "\",";
            file_put_contents($topicsFile, str_replace($currentTopics, $newTopics, $topicsContent));
        }
        
        $success = true;
        $createdNumber = $nextNumber;
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$langStrings = getAdminLangStrings($language);
?>

<!DOCTYPE html>
<html lang="<?= $language ?>">
<head>
    <meta charset="UTF-8">
    <title><?= $langStrings['page_title'] ?> - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
    <div class="card mx-auto" style="max-width: 800px;">
        <div class="card-body text-center">
            <?php if ($error): ?>
                <div class="alert alert-danger mb-4">
                    <h4 class="alert-heading"><?= $langStrings['error'] ?>!</h4>
                    <p><?= htmlspecialchars($error) ?></p>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <h2 class="text-success mb-4">✅ <?= $langStrings['success_title'] ?></h2>
                <p class="mb-4"><?= sprintf($langStrings['success_message'], htmlspecialchars($topicName), $createdNumber) ?></p>
                <div class="d-flex justify-content-center gap-3 mb-4">
                    <a href="/cybermath.com/language/<?= $language ?>/theory/topic<?= $createdNumber ?>.php" class="btn btn-primary" target="_blank">
                        <?= $langStrings['view_theory'] ?>
                    </a>
                    <a href="/cybermath.com/language/<?= $language ?>/tasks/topic<?= $createdNumber ?>.php" class="btn btn-success" target="_blank">
                        <?= $langStrings['view_tasks'] ?>
                    </a>
                </div>
            <?php else: ?>
                <h2 class="text-danger mb-4">❌ <?= $langStrings['fail_title'] ?></h2>
                <p><?= $error ? sprintf($langStrings['fail_message_with_reason'], $error) : $langStrings['fail_message'] ?></p>
            <?php endif; ?>
            
            <div class="mt-4">
                <a href="create_topic.php?lang=<?= $language ?>" class="btn btn-outline-primary me-2">
                    <?= $langStrings['create_new'] ?>
                </a>
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <?= $langStrings['back_to_admin'] ?>
                </a>
            </div>
        </div>
    </div>
</body>
</html>