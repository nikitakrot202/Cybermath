<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/admin_login.php');
    exit;
}

// Явно определяем язык из сессии или POST
$language = isset($_POST['language']) ? $_POST['language'] : (isset($_SESSION['admin_lang']) ? $_SESSION['admin_lang'] : 'ru');

// Константы для загрузки изображений
define('MAX_IMAGE_SIZE', 2 * 1024 * 1024); // 2MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('MATH_TASKS_IMAGES_DIR', "../language/$language/math_tasks/images");

function createMathTasksFile($path, $content) {
    $file = fopen($path, 'w');
    fwrite($file, $content);
    fclose($file);
}

function generateRandomValue($min, $max) {
    return rand($min, $max);
}

function calculateAnswer($formula, $values) {
    extract($values);
    return eval("return $formula;");
}

function updateMathTasksIndex($topicId, $topicName, $taskCount, $language) {
    $indexFile = "../language/$language/math_tasks/index.php";
    
    if (!file_exists($indexFile)) {
        file_put_contents($indexFile, "<?php\n\$topics = [];\n\$tasksCount = [];\n?>");
    }
    
    $content = file_get_contents($indexFile);
    
    // Обновляем массив тем
    if (preg_match('/\$topics\s*=\s*\[([^\]]*)\]/s', $content, $matches)) {
        $newTopics = $matches[1] . (!empty($matches[1]) ? "\n    " : "") . "$topicId => \"$topicName\",";
        $content = str_replace($matches[0], '$topics = [' . $newTopics . "\n];", $content);
    }
    
    // Обновляем массив с количеством задач
    if (preg_match('/\$tasksCount\s*=\s*\[([^\]]*)\]/s', $content, $matches)) {
        $newTasksCount = $matches[1] . (!empty($matches[1]) ? "\n    " : "") . "$topicId => $taskCount,";
        $content = str_replace($matches[0], '$tasksCount = [' . $newTasksCount . "\n];", $content);
    }
    
    file_put_contents($indexFile, $content);
}

$success = false;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $topicName = trim($_POST['topic_name']);
        $taskCount = (int)$_POST['task_count'];
        $tasks = $_POST['tasks'];
        
        if (count($tasks) != $taskCount) {
            throw new Exception("Количество задач не совпадает с введенными данными");
        }
        
        $existing = glob("../language/$language/math_tasks/topic*.php");
        $nextNumber = count($existing) + 1;
        
        if (!file_exists(MATH_TASKS_IMAGES_DIR)) {
            mkdir(MATH_TASKS_IMAGES_DIR, 0755, true);
        }
        
        $tasksArrayContent = "[\n";
        
        foreach ($tasks as $i => $taskData) {
            $values = [
                'x' => generateRandomValue($taskData['min_value'], $taskData['max_value']),
                'y' => generateRandomValue($taskData['min_value'], $taskData['max_value']),
                'z' => generateRandomValue($taskData['min_value'], $taskData['max_value'])
            ];
            
            $question = $taskData['question_template'];
            foreach ($values as $key => $value) {
                $question = str_replace("{" . $key . "}", $value, $question);
            }
            
            $answer = calculateAnswer($taskData['answer_formula'], $values);
            
            $tasksArrayContent .= "    " . ($i) . " => [\n";
            $tasksArrayContent .= "        'question' => \"" . addslashes($question) . "\",\n";
            $tasksArrayContent .= "        'answer' => \"" . $answer . "\",\n";
            $tasksArrayContent .= "        'formula' => \"" . addslashes($taskData['answer_formula']) . "\",\n";
            $tasksArrayContent .= "        'values' => " . var_export($values, true) . "\n";
            $tasksArrayContent .= "    ],\n";
        }
        
        $tasksArrayContent .= "];";
        
        $mathTasksContent = generateMathTasksContent($topicName, $nextNumber, $tasksArrayContent, $language);
        $mathTasksPath = "../language/$language/math_tasks/topic{$nextNumber}.php";
        createMathTasksFile($mathTasksPath, $mathTasksContent);
        
        updateMathTasksIndex($nextNumber, $topicName, $taskCount, $language);

        $success = true;
        $createdNumber = $nextNumber;
        
    } catch (Exception $e) {
        $error = $e->getMessage();
        $success = false;
    }
}

function generateMathTasksContent($topicName, $nextNumber, $tasksArrayContent, $language) {
    $title = htmlspecialchars($topicName);
    
    // Все сообщения только на русском для русской версии
    $rewardText = 'монет';
    $backText = 'Назад к темам';
    $correctText = 'Правильно!';
    $wrongText = 'Неправильный ответ';
    $taskText = 'Задача';
    $givenText = 'Дано';
    $solutionText = 'Решение';
    $answerText = 'Ответ';
    $checkText = 'Проверить';
    $prevText = 'Предыдущая';
    $nextText = 'Следующая';
    $requiredFieldsText = 'Все поля должны быть заполнены!';
    $alreadySolvedText = 'Правильно! Но вы уже решали эту задачу ранее.';
    
    return <<<PHP
<?php
session_start();
require_once '../../../db.php';

if (!isset(\$_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

const TASK_REWARD = 70;
\$language = '$language';
\$user_id = \$_SESSION['user_id'];
\$topic_id = $nextNumber;

\$tasks = $tasksArrayContent;

if (\$_SERVER['REQUEST_METHOD'] === 'POST') {
    \$task_id = (int)\$_POST['task_id'];
    \$given = trim(\$_POST['given']);
    \$solution = trim(\$_POST['solution']);
    \$user_answer = trim(\$_POST['answer']);

    if (empty(\$given) || empty(\$solution) || empty(\$user_answer)) {
        \$_SESSION['error_message'] = "$requiredFieldsText";
        header("Location: topic{\$topic_id}.php?task={\$task_id}");
        exit();
    }

    \$is_correct = (\$user_answer === \$tasks[\$task_id]['answer']);
    \$reward = 0;

    \$stmt = \$pdo->prepare("SELECT COUNT(*) FROM user_tasks WHERE user_id = ? AND topic_id = ? AND task_id = ? AND is_correct = 1");
    \$stmt->execute([\$user_id, \$topic_id, \$task_id]);
    \$already_solved = \$stmt->fetchColumn() > 0;

    if (\$is_correct) {
        if (!\$already_solved) {
            \$reward = TASK_REWARD;
            \$stmt = \$pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?");
            \$stmt->execute([\$reward, \$user_id]);
            \$_SESSION['success_message'] = "$correctText Вы заработали {\$reward} $rewardText.";
        } else {
            \$_SESSION['success_message'] = "$alreadySolvedText";
        }
    } else {
        \$_SESSION['error_message'] = "$wrongText";
    }

    \$stmt = \$pdo->prepare("INSERT INTO user_tasks (user_id, topic_id, task_id, given, solution, answer, is_correct, reward) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    \$stmt->execute([\$user_id, \$topic_id, \$task_id, \$given, \$solution, \$user_answer, \$is_correct, \$reward]);

    header("Location: topic{\$topic_id}.php?task={\$task_id}");
    exit();
}

\$current_task = isset(\$_GET['task']) ? (int)\$_GET['task'] : 0;
if (!isset(\$tasks[\$current_task])) {
    \$current_task = 0;
}
?>
<!DOCTYPE html>
<html lang="\$language">
<head>
    <meta charset="UTF-8">
    <title>$taskText: $title - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #f5f7fa, #c3cfe2); }
        .task-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 20px;
        }
        .form-section {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
        }
        .reward-badge {
            background-color: #00b894;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: bold;
        }
        .task-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        .task-number {
            font-weight: bold;
            font-size: 1.1rem;
        }
    </style>
</head>
<body class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-primary">🧩 $title</h1>
        <a href="index.php" class="btn btn-outline-secondary">← $backText</a>
    </div>

    <?php if (isset(\$_SESSION['error_message'])): ?>
        <div class="alert alert-danger mb-4">
            <?= \$_SESSION['error_message']; unset(\$_SESSION['error_message']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset(\$_SESSION['success_message'])): ?>
        <div class="alert alert-success mb-4">
            <?= \$_SESSION['success_message']; unset(\$_SESSION['success_message']); ?>
        </div>
    <?php endif; ?>

    <div class="task-nav">
        <div><span class="task-number">$taskText <?= \$current_task + 1 ?> / <?= count(\$tasks) ?></span></div>
        <div>
            <?php if (\$current_task > 0): ?>
                <a href="topic<?= \$topic_id ?>.php?task=<?= \$current_task - 1 ?>" class="btn btn-outline-primary btn-sm me-2">← $prevText</a>
            <?php endif; ?>
            <?php if (\$current_task < count(\$tasks) - 1): ?>
                <a href="topic<?= \$topic_id ?>.php?task=<?= \$current_task + 1 ?>" class="btn btn-outline-primary btn-sm">$nextText →</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="task-container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>$taskText <?= \$current_task + 1 ?></h3>
            <span class="reward-badge">+<?= TASK_REWARD ?> $rewardText</span>
        </div>

        <div class="mb-4">
            <?= htmlspecialchars_decode(\$tasks[\$current_task]['question']) ?>
        </div>

        <form method="post">
            <input type="hidden" name="task_id" value="<?= \$current_task ?>">
            <div class="form-section">
                <label for="given" class="form-label">$givenText:</label>
                <textarea class="form-control" id="given" name="given" rows="3" required></textarea>
            </div>
            <div class="form-section">
                <label for="solution" class="form-label">$solutionText:</label>
                <textarea class="form-control" id="solution" name="solution" rows="5" required></textarea>
            </div>
            <div class="form-section">
                <label for="answer" class="form-label">$answerText:</label>
                <input type="text" class="form-control" id="answer" name="answer" required>
            </div>
            <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary btn-lg px-5">$checkText</button>
            </div>
        </form>
    </div>
</body>
</html>
PHP;
}
?>

<!DOCTYPE html>
<html lang="<?= $language ?>">
<head>
    <meta charset="UTF-8">
    <title>Генерация математических задач - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
    <div class="card mx-auto" style="max-width: 800px;">
        <div class="card-body text-center">
            <?php if ($error): ?>
                <div class="alert alert-danger mb-4">
                    <h4 class="alert-heading">Ошибка!</h4>
                    <p><?= htmlspecialchars($error) ?></p>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <h2 class="text-success mb-4">✅ Задачи успешно созданы!</h2>
                <p class="mb-4">Тема "<?= htmlspecialchars($topicName) ?>" была сохранена как тема №<?= $createdNumber ?>.</p>
                <p class="mb-4">Создано <?= count($tasks) ?> задач.</p>
                
                <div class="d-flex justify-content-center gap-3 mb-4">
                    <a href="/cybermath.com/language/<?= $language ?>/math_tasks/topic<?= $createdNumber ?>.php" 
                       class="btn btn-primary" target="_blank">
                        Открыть задачи
                    </a>
                </div>
            <?php else: ?>
                <h2 class="text-danger mb-4">❌ Ошибка при создании задач</h2>
                <p>Не удалось создать задачи. <?= $error ? 'Причина: ' . $error : 'Пожалуйста, попробуйте снова.' ?></p>
            <?php endif; ?>
            
            <div class="mt-4">
                <a href="create_topic.php?lang=<?= $language ?>" class="btn btn-outline-primary me-2">
                    Создать новые задачи
                </a>
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    Вернуться в админку
                </a>
            </div>
        </div>
    </div>
</body>
</html>