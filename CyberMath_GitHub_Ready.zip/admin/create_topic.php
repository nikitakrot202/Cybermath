<?php
session_start();
require_once '../db.php';
require_once 'language_functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/admin_login.php');
    exit;
}

// Язык из GET-параметра
$language = isset($_GET['lang']) && $_GET['lang'] === 'et' ? 'et' : 'ru';
$languageName = $language === 'et' ? 'Eesti keeles' : 'На русском';

// Константы путей с учетом языка
define('THEORY_DIR', "../language/$language/theory");
define('TASKS_DIR', "../language/$language/tasks");
define('MATH_TASKS_DIR', "../language/$language/math_tasks");

// Обработка удаления темы
if (isset($_GET['delete_topic'])) {
    $topicNum = (int)$_GET['delete_topic'];
    
    // Удаляем файлы с учетом языка
    $theoryFile = "../language/$language/theory/topic{$topicNum}.php";
    if (file_exists($theoryFile)) unlink($theoryFile);
    
    $taskFile = "../language/$language/tasks/topic{$topicNum}.php";
    if (file_exists($taskFile)) unlink($taskFile);
    
    // Удаляем связанные изображения
    $images = glob("../language/$language/theory/images/topic{$topicNum}_*.*");
    foreach ($images as $image) {
        if (file_exists($image)) unlink($image);
    }
    
    // Обновляем список тем
    $theoryIndexFile = "../language/$language/theory/index.php";
    if (file_exists($theoryIndexFile)) {
        $content = file_get_contents($theoryIndexFile);
        
        if (preg_match('/\$topics\s*=\s*\[([^\]]+)\]/s', $content, $matches)) {
            $topicsArray = explode("\n", trim($matches[1]));
            $newTopics = [];
            
            foreach ($topicsArray as $line) {
                if (!str_contains($line, "\"{$topicNum}\" =>") && !str_contains($line, "'{$topicNum}' =>")) {
                    $newTopics[] = $line;
                }
            }
            
            $content = str_replace(
                $matches[0], 
                '$topics = [' . "\n    " . implode("\n    ", $newTopics) . "\n];", 
                $content
            );
        }
        
        file_put_contents($theoryIndexFile, $content);
    }
    
    header("Location: create_topic.php?lang=$language&deleted={$topicNum}");
    exit;
}

// Обработка удаления задач
if (isset($_GET['delete_task'])) {
    $taskNum = (int)$_GET['delete_task'];
    $taskFile = "../language/$language/math_tasks/topic{$taskNum}.php";
    
    if (file_exists($taskFile)) unlink($taskFile);
    
    // Обновляем список задач
    $tasksIndexFile = "../language/$language/math_tasks/index.php";
    $content = file_get_contents($tasksIndexFile);
    
    if (preg_match('/\$topics\s*=\s*\[([^\]]+)\]/s', $content, $matches)) {
        $topicsArray = explode("\n", trim($matches[1]));
        $newTopics = [];
        
        foreach ($topicsArray as $line) {
            if (!str_contains($line, "$taskNum =>")) {
                $newTopics[] = $line;
            }
        }
        
        $content = str_replace(
            $matches[0], 
            '$topics = [' . "\n    " . implode("\n    ", $newTopics) . "\n];", 
            $content
        );
    }
    
    if (preg_match('/\$tasksCount\s*=\s*\[([^\]]+)\]/s', $content, $matches)) {
        $tasksCountArray = explode("\n", trim($matches[1]));
        $newTasksCount = [];
        
        foreach ($tasksCountArray as $line) {
            if (!str_contains($line, "$taskNum =>")) {
                $newTasksCount[] = $line;
            }
        }
        
        $content = str_replace(
            $matches[0], 
            '$tasksCount = [' . "\n    " . implode("\n    ", $newTasksCount) . "\n];", 
            $content
        );
    }
    
    file_put_contents($tasksIndexFile, $content);
    
    header("Location: create_topic.php?lang=$language&deleted_task={$taskNum}");
    exit;
}

// Получаем языковые строки
$langStrings = getAdminLangStrings($language);

// Список существующих тем
$theoryFiles = glob(THEORY_DIR . "/topic*.php");
$topicsList = [];

foreach ($theoryFiles as $file) {
    $num = (int)preg_replace('/[^0-9]/', '', basename($file));
    $content = file_get_contents($file);
    if (preg_match('/<title>(.*?)<\/title>/', $content, $matches)) {
        $title = str_replace(' - CyberMath', '', $matches[1]);
        $topicsList[$num] = [
            'title' => $title,
            'theory_file' => $file
        ];
    }
}

// Список существующих задач
$taskFiles = glob(MATH_TASKS_DIR . "/topic*.php");
$tasksList = [];

foreach ($taskFiles as $file) {
    $num = (int)preg_replace('/[^0-9]/', '', basename($file));
    $content = file_get_contents($file);
    if (preg_match('/<title>'.$langStrings['tasks_for'].': (.*?)<\/title>/', $content, $matches)) {
        $title = $matches[1];
        $tasksList[$num] = [
            'title' => $title,
            'task_file' => $file,
            'task_count' => substr_count($content, "'question' =>")
        ];
    }
}

ksort($topicsList);
ksort($tasksList);
?>

<!DOCTYPE html>
<html lang="<?= $language ?>">
<head>
    <meta charset="UTF-8">
    <title><?= $langStrings['create_topic_title'] ?> - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }
        .task-item {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
        }
        .topics-list {
            max-height: 500px;
            overflow-y: auto;
        }
        .topic-item {
            transition: all 0.2s;
        }
        .topic-item:hover {
            background-color: #f8f9fa;
        }
        .delete-topic {
            opacity: 0;
            transition: opacity 0.2s;
        }
        .topic-item:hover .delete-topic {
            opacity: 1;
        }
        .img-preview {
            max-width: 150px;
            max-height: 150px;
            margin-top: 10px;
            display: none;
            border-radius: 5px;
        }
        /* Стили для кнопок языков */
        .btn-language {
            margin-right: 5px;
        }
        .btn-language.active {
            font-weight: bold;
            border-width: 2px;
        }
    </style>
</head>
<body class="container py-5">
    <div class="language-switcher mb-4">
        <a href="?lang=ru" class="btn btn-language btn-outline-primary <?= $language === 'ru' ? 'active' : '' ?>">Русский</a>
        <a href="?lang=et" class="btn btn-language btn-outline-primary <?= $language === 'et' ? 'active' : '' ?>">Eesti</a>
    </div>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= sprintf($langStrings['topic_deleted'], htmlspecialchars($_GET['deleted'])) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="admin-nav mb-4">
        <a href="dashboard.php" class="btn btn-outline-secondary me-2">← <?= $langStrings['back_to_admin'] ?></a>
        <a href="/cybermath.com/language/<?= $language ?>/theory/index.php" class="btn btn-outline-primary me-2" target="_blank">
            <?= $langStrings['view_topics_list'] ?>
        </a>
        <a href="/cybermath.com/language/<?= $language ?>/math_tasks/index.php" class="btn btn-outline-primary" target="_blank">
            <?= $langStrings['view_tasks_list'] ?>
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="form-container">
                <h1 class="text-center mb-4">📝 <?= $langStrings['create_new_topic'] ?></h1>
                
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="theory-tab" data-bs-toggle="tab" data-bs-target="#theory" type="button" role="tab">
                            <?= $langStrings['theory_and_examples'] ?>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tasks-tab" data-bs-toggle="tab" data-bs-target="#tasks" type="button" role="tab">
                            <?= $langStrings['math_tasks'] ?>
                        </button>
                    </li>
                </ul>
                
                <div class="tab-content" id="myTabContent">
                    <!-- Вкладка теории -->
                    <div class="tab-pane fade show active" id="theory" role="tabpanel">
                        <form method="POST" action="generate_topic.php" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="form-label"><?= $langStrings['topic_name'] ?>:</label>
                                <input type="text" name="topic_name" class="form-control" required>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label"><?= $langStrings['theory_content'] ?>:</label>
                                <textarea name="theory_text" class="form-control" rows="8" required></textarea>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label"><?= $langStrings['theory_image'] ?>:</label>
                                <input type="file" name="theory_image" class="form-control" accept="image/*" id="theory-image-input">
                                <small class="text-muted"><?= $langStrings['image_requirements'] ?></small>
                                <img id="theory-image-preview" class="img-preview">
                            </div>

                            <div class="mb-4">
                                <label class="form-label"><?= $langStrings['tasks'] ?>:</label>
                                <div id="tasks-container" class="mb-3"></div>
                                <button type="button" onclick="addTask()" class="btn btn-outline-primary">
                                    + <?= $langStrings['add_task'] ?>
                                </button>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-success px-4 py-2">
                                    <?= $langStrings['generate_topic'] ?> 🚀
                                </button>
                                <a href="dashboard.php" class="btn btn-secondary px-4 py-2"><?= $langStrings['cancel'] ?></a>
                            </div>

                            <input type="hidden" name="language" value="<?= $language ?>">
                        </form>
                    </div>
                    
                    <!-- Вкладка задач -->
                    <div class="tab-pane fade" id="tasks" role="tabpanel">
                        <form method="POST" action="generate_math_tasks.php" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="form-label"><?= $langStrings['tasks_topic_name'] ?>:</label>
                                <input type="text" name="topic_name" class="form-control" required>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label"><?= $langStrings['task_count'] ?>:</label>
                                <input type="number" name="task_count" class="form-control" min="1" max="20" value="5" required id="task-count">
                            </div>
                            
                            <div id="math-tasks-container"></div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary px-4 py-2">
                                    <?= $langStrings['generate_tasks'] ?> 🚀
                                </button>
                            </div>

                            <input type="hidden" name="language" value="<?= $language ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="dual-card-container">
                <!-- Список тем -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">📚 <?= $langStrings['existing_topics'] ?></h5>
                        <span class="badge bg-light text-dark"><?= count($topicsList) ?></span>
                    </div>
                    <div class="card-body topics-list p-0">
                        <?php if (!empty($topicsList)): ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($topicsList as $num => $topic): ?>
                                    <div class="list-group-item topic-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <a href="/cybermath.com<?= str_replace('..', '', $topic['theory_file']) ?>" 
                                               target="_blank" 
                                               class="text-decoration-none">
                                                <span class="fw-bold"><?= $langStrings['topic'] ?> <?= $num ?>:</span>
                                                <span><?= htmlspecialchars($topic['title']) ?></span>
                                            </a>
                                        </div>
                                        <div>
                                            <a href="?lang=<?= $language ?>&delete_topic=<?= $num ?>" 
                                               class="delete-topic btn btn-sm btn-outline-danger"
                                               onclick="return confirm('<?= $langStrings['confirm_delete_topic'] ?> <?= $num ?>?')">
                                                <?= $langStrings['delete'] ?>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="p-3 text-center text-muted">
                                <?= $langStrings['no_topics'] ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Список задач -->
                <div class="card">
                    <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">📝 <?= $langStrings['existing_tasks'] ?></h5>
                        <span class="badge bg-light text-dark"><?= count($tasksList) ?></span>
                    </div>
                    <div class="card-body topics-list p-0">
                        <?php if (!empty($tasksList)): ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($tasksList as $num => $task): ?>
                                    <div class="list-group-item topic-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <a href="/cybermath.com<?= str_replace('..', '', $task['task_file']) ?>" 
                                               target="_blank" 
                                               class="text-decoration-none">
                                                <span class="fw-bold"><?= $langStrings['tasks'] ?> <?= $num ?>:</span>
                                                <span><?= htmlspecialchars($task['title']) ?></span>
                                                <span class="badge bg-info ms-2"><?= $task['task_count'] ?> <?= $langStrings['tasks'] ?></span>
                                            </a>
                                        </div>
                                        <div>
                                            <a href="?lang=<?= $language ?>&delete_task=<?= $num ?>" 
                                               class="delete-topic btn btn-sm btn-outline-danger"
                                               onclick="return confirm('<?= $langStrings['confirm_delete_tasks'] ?> <?= $num ?>?')">
                                                <?= $langStrings['delete'] ?>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="p-3 text-center text-muted">
                                <?= $langStrings['no_tasks'] ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Добавление задания
        function addTask() {
            const container = document.getElementById('tasks-container');
            const index = container.children.length;
            
            const taskDiv = document.createElement('div');
            taskDiv.className = 'task-item';
            taskDiv.innerHTML = `
                <h5><?= $langStrings['task'] ?> ${index + 1}</h5>
                <div class="mb-3">
                    <label class="form-label"><?= $langStrings['question'] ?>:</label>
                    <input type="text" name="tasks[${index}][question]" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?= $langStrings['task_image'] ?>:</label>
                    <input type="file" name="tasks[${index}][image]" class="form-control" accept="image/*">
                    <img id="task-image-preview-${index}" class="img-preview">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?= $langStrings['options'] ?>:</label>
                    <input type="text" name="tasks[${index}][options]" class="form-control" required>
                    <small class="text-muted"><?= $langStrings['options_hint'] ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?= $langStrings['correct_answer'] ?>:</label>
                    <input type="text" name="tasks[${index}][answer]" class="form-control" required>
                </div>
                <button type="button" onclick="this.parentNode.remove()" class="btn btn-outline-danger btn-sm">
                    <?= $langStrings['delete_task'] ?>
                </button>
            `;
            container.appendChild(taskDiv);
            
            // Обработчик предпросмотра изображения
            const imageInput = taskDiv.querySelector('input[type="file"]');
            const preview = taskDiv.querySelector('.img-preview');
            
            imageInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        preview.src = event.target.result;
                        preview.style.display = 'block';
                    }
                    reader.readAsDataURL(file);
                } else {
                    preview.style.display = 'none';
                }
            });
        }
        
        // Инициализация математических задач
        document.getElementById('task-count').addEventListener('change', function() {
            const container = document.getElementById('math-tasks-container');
            const count = parseInt(this.value);
            container.innerHTML = '';
            
            for (let i = 0; i < count; i++) {
                const taskDiv = document.createElement('div');
                taskDiv.className = 'task-item mb-4 p-3 border rounded';
                taskDiv.innerHTML = `
                    <h5><?= $langStrings['task'] ?> ${i+1}</h5>
                    <div class="mb-3">
                        <label class="form-label"><?= $langStrings['question_template'] ?>:</label>
                        <textarea name="tasks[${i}][question_template]" class="form-control" rows="3" required></textarea>
                        <small class="text-muted"><?= $langStrings['variables_hint'] ?></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?= $langStrings['answer_formula'] ?>:</label>
                        <input type="text" name="tasks[${i}][answer_formula]" class="form-control" required>
                        <small class="text-muted"><?= $langStrings['formula_hint'] ?></small>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label class="form-label"><?= $langStrings['min_value'] ?>:</label>
                            <input type="number" name="tasks[${i}][min_value]" class="form-control" value="1" required>
                        </div>
                        <div class="col">
                            <label class="form-label"><?= $langStrings['max_value'] ?>:</label>
                            <input type="number" name="tasks[${i}][max_value]" class="form-control" value="10" required>
                        </div>
                    </div>
                `;
                container.appendChild(taskDiv);
            }
        });

        // Предпросмотр изображения для теории
        document.getElementById('theory-image-input').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('theory-image-preview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    preview.src = event.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        });

        // Инициализация при загрузке
        document.addEventListener('DOMContentLoaded', function() {
            addTask();
            document.getElementById('task-count').dispatchEvent(new Event('change'));
        });
    </script>
</body>
</html>
