# CyberMath — Gamified Mathematics Learning Platform

![PHP](https://img.shields.io/badge/PHP-8.x-777BB4) ![MySQL](https://img.shields.io/badge/MySQL%2FMariaDB-database-4479A1) ![Status](https://img.shields.io/badge/Project-diploma_project-blue)

**CyberMath** is a mathematics learning website with gamification features. It was developed as a **team diploma project by three vocational-school students**.

## My contribution
I worked on **frontend and backend development**, alongside another student who also developed code. The third teammate helped with visual design and product ideas. This is a collaborative project, not a solo project.

## Main features
- User registration and authentication
- Mathematics exercises and learning content (Russian and Estonian)
- Progress tracking and leaderboard
- Admin and moderator functions
- PDF features via third-party PHP libraries

## Tech stack
- PHP and PDO, MySQL/MariaDB
- HTML, CSS, JavaScript
- Composer packages: `vlucas/phpdotenv`, `setasign/fpdf`, `tecnickcom/tcpdf`

## Local setup
Requirements: PHP 8.x with `pdo_mysql`, MySQL or MariaDB, Composer, and a local PHP-compatible web server. Depending on your configuration, PHP extensions required by PDF libraries may also be needed.

1. Clone the repository into your local web directory.
2. Run `composer install` in the project root.
3. Create an empty MySQL/MariaDB database called `cybermath` (or choose your own name).
4. Import **`database/schema.sql`** into that database. This is a **schema-only** export; no real users or records are included.
5. Copy `.env.example` to `.env` and enter **local development credentials** for your database.
6. Serve the directory using your local PHP web server (for example, `php -S localhost:8000`, then open `http://localhost:8000`). Alternatively, use Apache/XAMPP.
7. The root `index.php` is a landing page. Explore the site through its navigation and localized pages. Create a fresh test account to test authentication and learning features.

> The setup steps are based on the uploaded PHP project structure and have **not been run in a clean test environment**. Some administrative features may require creating local admin test accounts. No production credentials are included.

## Security / privacy
- `.env`, credentials, private user records, hash-generation helper scripts, IDE files and dependency folders are excluded.
- The bundled database is **schema-only**. Never import a real production dump into a public Git repository.
- Do not store real user data or secrets in commits, including old commit history.

## Team & credit
Built by a team of three students during a software-development diploma course. Named teammate attribution can be added after agreement.
