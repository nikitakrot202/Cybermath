<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <title>Kätt - CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            position: relative;
            overflow-x: hidden;
        }
        h1 {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
        }

        .task-navigation {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
        }
        .task-navigation .btn {
            min-width: 120px;
        }
        .task-counter {
            font-size: 1.2rem;
            margin-bottom: 15px;
            font-weight: bold;
            text-align: center;
        }

        .card {
            background: #ffffffcc;
            border: none;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .emoji {
            position: absolute;
            font-size: 2rem;
            animation: float 10s infinite linear;
            opacity: 0.8;
        }
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 0.8; }
            100% { transform: translateY(-200px) rotate(360deg); opacity: 0; }
        }
        .btn-primary {
            background-color: #6c5ce7;
            border: none;
        }
        .btn-primary:hover {
            background-color: #5a4bd1;
        }
        .img-fluid {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin: 15px 0;
        }
    </style>
</head>
<body class="container py-5 position-relative">
    <?php for ($i = 0; $i < 15; $i++): ?>
        <div class="emoji" style="left: <?= rand(0, 100) ?>%; top: <?= rand(10, 100) ?>px; animation-delay: <?= rand(0, 10) ?>s;">
            <?= ['🔢','✨','🧠','➕','➖','📘','🚀','🧮'][rand(0, 7)] ?>
        </div>
    <?php endfor; ?>

    <div class="card mx-auto" style="max-width: 900px;">
        <h1 class="mb-4 text-center">🔢 Kätt</h1>
        <div class='text-center my-4'><img src='images/topic21_theory.jpg' class='img-fluid rounded' alt='Illustration'></div>
        <div class="theory-content">fsdfdsfsdfdsf</div>
        <p class="text-center mt-4">
            <a href="../tasks/topic21.php" class="btn btn-primary btn-lg fw-bold">Mine näidete juurde 🚀</a>
        </p>
    </div>
</body>
</html>