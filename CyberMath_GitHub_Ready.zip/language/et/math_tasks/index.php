<?php
session_start();
require_once '../../../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$topics = [
    1 => "Liitmine ja lahutamine",
    2 => "Korrutamine ja jagamine",
    3 => "Loomulikud, terved, ratsionaalsed ja irratsionaalsed arvud",
    4 => "Kümnend- ja harilikud murrud",
    5 => "Protsendid",
    6 => "Aritmeetiline ja geomeetriline jada",
    7 => "Astmed ja juured",
    8 => "Logaritmid",
    9 => "Lineaarsed võrrandid",
    10 => "Lineaarsete võrrandite süsteemid",
    11 => "Ruutvõrrandid ja diskriminant",
    12 => "Võrratused",
    13 => "Muutuja ja funktsioon",
    14 => "Funktsioonide graafikud",
    15 => "Trigonomeetria alused",
    16 => "Koordinaattasand",
    17 => "Pythagorase teoreem",
    18 => "Geomeetrilised kujundid",
    19 => "Pindala ja ümbermõõt",
    20 => "Sissejuhatus tõenäosusesse",           
];

foreach ($topics as $id => $title) {
    $file = "topic{$id}.php";
    if (file_exists($file)) {
        $content = file_get_contents($file);
        preg_match_all("/\d+\s*=>\s*\[/", $content, $matches);
        $tasksCount[$id] = count($matches[0]);
    } else {
        $tasksCount[$id] = 0;
    }
}

// Ülesannete arv igas teemas
$tasksCount = [
    1 => 8,
    2 => 7,
    3 => 6,
    4 => 8,
    5 => 7,
    6 => 5,
    7 => 6,
    8 => 5,
    9 => 7,
    10 => 6,
    11 => 6,
    12 => 5,
    13 => 6,
    14 => 5,
    15 => 6,
    16 => 7,
    17 => 5,
    18 => 8,
    19 => 7,
    20 => 6,
];
?>

<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <title>Ülesannete lahendamine – CyberMath</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
        }

        .btn-outline-secondary {
            --bs-btn-color: #6c5ce7;
            --bs-btn-border-color:rgb(124, 111, 224);
            --bs-btn-hover-color: #fff;
            --bs-btn-hover-bg: #6c5ce7;
            --bs-btn-hover-border-color: #6c5ce7;
            --bs-btn-focus-shadow-rgb: 108,117,125;
            --bs-btn-active-color: #fff;
            --bs-btn-active-bg: #6c5ce7;
            --bs-btn-active-border-color: #6c5ce7;
            --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            --bs-btn-disabled-color: #6c5ce7;
            --bs-btn-disabled-bg: transparent;
            --bs-btn-disabled-border-color: #6c5ce7;
            --bs-gradient: none;
        }

        .topic-card {
            transition: all 0.3s;
            border-radius: 15px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .topic-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        .reward-badge {
            background-color: #00b894;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: bold;
        }
        .task-count {
            color: #6c5ce7;
            font-weight: 500;
        }
        .btn-solve {
            background-color: #6c5ce7;
            color: white;
            border: none;
        }
        .btn-solve:hover {
            background-color: #5649c0;
            color: white;
        }
    </style>
</head>
<body class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-primary">🧩 Lahenda ülesandeid</h1>
        <a href="../profile.php" class="btn btn-outline-secondary">← Profiilile</a>
    </div>

    <div class="alert alert-info mb-4">
        <h5 class="alert-heading">Kuidas see töötab?</h5>
        <p class="mb-0">
            Vali teema ja ülesanne, lahenda see ning saa <span class="reward-badge">+70 münti</span> iga õigesti lahendatud ülesande eest!
            Igas ülesandes tuleb enne kontrollimist täita kõik väljad (Antud, Lahendus, Vastus).
        </p>
    </div>

    <div class="mb-4">
        <input type="text" id="searchInput" class="form-control" placeholder="🔍 Otsi teemasid...">
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($topics as $id => $topic): ?>
            <div class="col">
                <div class="card topic-card h-100">
                    <div class="card-body d-flex flex-column">
                        <h4 class="mb-3"><?= htmlspecialchars($topic) ?></h4>
                        <p class="task-count mb-3"><?= $tasksCount[$id] ?> ülesannet</p>
                        
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-muted small">Teema <?= $id ?></span>
                                <a href="topic<?= $id ?>.php" class="btn btn-solve">Vali</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

<script>
    document.getElementById('searchInput').addEventListener('input', function () {
        const query = this.value.toLowerCase().trim();
        const cards = document.querySelectorAll('.col');

        if (query === '') {
            cards.forEach(card => card.style.display = '');
            return;
        }

        cards.forEach(card => {
            const title = card.querySelector('h4').textContent.toLowerCase();
            const topicNumber = card.querySelector('.text-muted').textContent.toLowerCase();
            
            if (title.includes(query) || topicNumber.includes(query)) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>
