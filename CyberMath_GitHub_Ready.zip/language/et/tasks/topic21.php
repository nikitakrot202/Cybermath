<?php
session_start();
require_once '../../../db.php';

$tasks = [
    [
        'question' => "<div class='text-center mb-3'><img src='images/topic21_task1.jpg' class='img-fluid rounded' alt='Task illustration'></div>sdfdsfdsfdsf",
        'options' => [3, 4],
        'answer' => 4
    ],
];

$currentTask = isset($_GET['task']) ? (int)$_GET['task'] : 1;
if ($currentTask < 1 || $currentTask > count($tasks)) {
    $currentTask = 1;
}

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$topic_id = 21;

$show_result = false;
$score = 0;
$user_answers = [];
$earned_bonus = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $show_result = true;

    foreach ($tasks as $i => $task) {
        $user_answer = $_POST['q' . $i] ?? null;
        $user_answers[$i] = $user_answer;

        if ($user_answer == $task['answer']) {
            $score++;
        }
    }

    if ($score === count($tasks)) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_topics WHERE user_id = ? AND topic_id = ?");
        $stmt->execute([$user_id, $topic_id]);
        $already_completed = $stmt->fetchColumn();

        if ($already_completed == 0) {
            $insert = $pdo->prepare("INSERT INTO user_topics (user_id, topic_id) VALUES (?, ?)");
            $insert->execute([$user_id, $topic_id]);
            $earned_bonus = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задачи: Kätt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f9f9f9, #eef3f7);
            font-family: 'Segoe UI', sans-serif;
        }
        .task-card {
            animation: fadeInUp 0.5s ease;
            transition: transform 0.3s;
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .task-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        }
        .task-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        .task-number {
            font-weight: bold;
            font-size: 1.1rem;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animated-alert {
            animation: fadeIn 0.8s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .btn-success {
            transition: background-color 0.3s;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .img-fluid {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin: 15px 0;
        }
        .task-navigation {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
        }
        .task-counter {
            font-size: 1.2rem;
            margin-bottom: 15px;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body class="container py-5">
    <h1 class="mb-4 text-center">🧠 Kätt</h1>

    <div class="task-counter">
        Задача <?= $currentTask ?> из <?= count($tasks) ?>
    </div>

    <?php if ($show_result): ?>
        <div class="alert alert-info animated-alert text-center fs-5">
            Вы правильно решили <?= $score ?> из <?= count($tasks) ?> задач!
            <?php if ($score === count($tasks) && $earned_bonus): ?>
                <br><strong class="text-success">+50 монет 💰</strong>
            <?php elseif ($score === count($tasks)): ?>
                <br><em class="text-muted">(уже пройдено ранее)</em>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-4 p-4 task-card">
            <h5><?= $tasks[$currentTask-1]['question'] ?></h5>
            <?php foreach ($tasks[$currentTask-1]['options'] as $opt): ?>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q<?= $currentTask-1 ?>" value="<?= $opt ?>"
                        <?= isset($user_answers[$currentTask-1]) && $user_answers[$currentTask-1] == $opt ? 'checked' : '' ?> 
                        <?= $show_result ? 'disabled' : '' ?>>
                    <label class="form-check-label"><?= $opt ?></label>
                </div>
            <?php endforeach; ?>

            <?php if ($show_result): ?>
                <?php if (!isset($user_answers[$currentTask-1])): ?>
                    <div class="mt-2 text-warning">❌ Нет ответа</div>
                <?php elseif ($user_answers[$currentTask-1] == $tasks[$currentTask-1]['answer']): ?>
                    <div class="mt-2 text-success">✅ Правильно!</div>
                <?php else: ?>
                    <div class="mt-2 text-danger">❌ Неправильно. Правильный ответ: <?= $tasks[$currentTask-1]['answer'] ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="task-nav mb-4">
            <div><span class="task-number">Задача <?= $currentTask ?> / <?= count($tasks) ?></span></div>
            <div>
                <?php if ($currentTask > 1): ?>
                    <a href="?task=<?= $currentTask - 1 ?>" class="btn btn-outline-primary btn-sm me-2">← Предыдущая</a>
                <?php endif; ?>
                <?php if ($currentTask < count($tasks)): ?>
                    <a href="?task=<?= $currentTask + 1 ?>" class="btn btn-outline-primary btn-sm">Следующая →</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="text-center mt-4">
            <?php if (!$show_result): ?>
                <button type="submit" class="btn btn-success btn-lg px-5">Показать результат</button>
            <?php elseif ($score < count($tasks)): ?>
                <a href="" class="btn btn-warning btn-lg px-5">Попробовать снова</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="text-center mt-4">
        <a href="../theory/index.php" class="btn btn-outline-secondary">← Назад к темам</a>
    </div>
</body>
</html>